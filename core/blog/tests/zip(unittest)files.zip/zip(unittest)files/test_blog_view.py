from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from blog.models import Post, Category
from datetime import datetime


User = get_user_model()


class TestBlogViews(TestCase):
    def setUp(self):
        self.client = Client()
        user = User.objects.create_user(password='sdfre@##Erewqqq233', email='wewwe@weweew.com')
        self.user = user
        profile = user.profile_set.all()[0]
        self.profile = profile
        post = Post.objects.create(author=self.profile, title='ddd', content='frr', status=False, category=Category.objects.create(name='trr'), published_dt=datetime.now())
        self.post = post
    
    def test_blog_index_url_successful_response(self):
        url = reverse('blog:index')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(str(response.content).find('index'))
        self.assertTemplateUsed(response, 'index.html')
    
    def test_blog_post_detail_logged_in_response(self):
        self.client.force_login(self.user)
        url = reverse('blog:post-detail', kwargs={'pk': self.post.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
    
    def test_blog_post_detail_anonymous_response(self):
        url = reverse('blog:post-detail', kwargs={'pk': self.post.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)
