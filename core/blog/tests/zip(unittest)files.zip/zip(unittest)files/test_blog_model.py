from django.test import TestCase
from blog.models import Post, Category
from datetime import datetime
from django.contrib.auth import get_user_model


User = get_user_model()


class TestPostModel(TestCase):
    def setUp(self):
        user = User.objects.create_user(password='sdfre@##Erewqqq233', email='wewwe@weweew.com')
        self.user = user
        profile = user.profile_set.all()[0]
        self.profile = profile
    
    def test_post_create_valid_data(self):
        post = Post.objects.create(author=self.profile, title='ddd', content='frr', status=False, category=Category.objects.create(name='trr'), published_dt=datetime.now())
        self.assertTrue(Post.objects.filter(id=post.id).exists())
