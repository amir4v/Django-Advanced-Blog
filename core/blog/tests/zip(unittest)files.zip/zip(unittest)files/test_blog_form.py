from django.test import SimpleTestCase, TestCase
from blog.forms import PostForm
from datetime import datetime
from blog.models import Category


class TestPostForm(TestCase):
    def test_post_form_with_valid_data(self):
        form = PostForm(data={
            'title': 'test',
            'content': 'test content',
            'status': True,
            'category': Category.objects.create(name='testication'),
            'published_dt': datetime.now(),
        })
        self.assertTrue(form.is_valid())
    
    def test_post_form_with_no_valid_data(self):
        form = PostForm(data={})
        self.assertFalse(form.is_valid())
